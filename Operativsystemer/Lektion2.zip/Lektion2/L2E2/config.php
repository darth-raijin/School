<?php
	$servername = "sql";
	$username = "root";
	$password = "";
	$dbname = "abook";
?>
